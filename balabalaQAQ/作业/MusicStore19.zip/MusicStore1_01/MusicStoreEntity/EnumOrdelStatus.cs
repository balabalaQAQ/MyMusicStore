﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicStoreEntity
{
    /// <summary>
    /// 订单的状态
    /// </summary>
    public enum EnumOrdelStatus
    {
        未付款,
        已付款,
        交易关闭
    }
}
