﻿namespace MusicStoreEntity.UserAndRole
{
    public enum ApplicationRoleType
    {
        适用于一般注册用户,
        适用于有管理权限用户,
        适用于系统管理人员
    }
}